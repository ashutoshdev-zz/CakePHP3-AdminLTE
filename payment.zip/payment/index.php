<?php
	/*
	 * This is an example page of the form fields required for a PayGate PayHost Web Payment transaction.
	 */
	include_once('../lib/php/global.inc.php');

	/*
	 * Include the helper PayHost SOAP class to make building the SOAP message a little easier
	 */
	include_once('paygate.payhost_soap.php');

	ini_set('display_errors',1);
	ini_set('default_socket_timeout', 300);

	$result    = '';
	$err       = '';

	/*
	 * Include Billing & Customer Address by default
	 */
	$incBilling  = 'incBilling';
	$incCustomer = 'incCustomer';

	if(isset($_POST['btnSubmit'])){

		session_name('paygate_payhost_testing_sample');
		session_start();

		/*
	     * Initiate the PAyHost SOAP helper class
	     */
		$payHostSoap = new PayHostSOAP($_POST);

		/*
		 * Generate SOAP from the input vars
		 */
		$xml = $payHostSoap->getSOAP();

		/*
		 * Create variables based on key names in $_POST
		 */
		extract($_POST,EXTR_OVERWRITE);

		/*
	     * Set the session vars
	     */
		$_SESSION['pgid']      = $pgid;
		$_SESSION['reference'] = $reference;
		$_SESSION['key']       = $encryptionKey;

		/**
		 *  disabling WSDL cache
		 */
		ini_set("soap.wsdl_cache_enabled", "0");

		/*
		 * Using PHP SoapClient to handle the request
		 */
		$soapClient = new SoapClient(PayHostSOAP::$process_url."?wsdl", array('trace' => 1)); //point to WSDL and set trace value to debug

		try {
			/*
			 * Send SOAP request
			 */
			$result = $soapClient->__soapCall('SinglePayment', array(
				new SoapVar($xml, XSD_ANYXML)
			));
		} catch (SoapFault $sf){
			/*
			 * handle errors
			 */
			$err = $sf->getMessage();
		}
	} else {
		session_name('paygate_payhost_testing_sample');
		session_start();
		session_destroy();
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<title>PayHost - Initiate</title>
		<link rel="stylesheet" href="/<?php echo $root; ?>/lib/css/bootstrap.min.css">
		<link rel="stylesheet" href="/<?php echo $root; ?>/lib/css/core.css">
	</head>
	<body>
		<div class="container-fluid" style="min-width: 320px;">
			
			<div style="background-color:#80b946; text-align: center; margin-top: 51px; margin-bottom: 15px; padding: 4px;"><strong>Initiate WebPayment</strong></div>
			<div class="container">
				<form role="form" class="form-horizontal text-left" action="index.php" method="post">
					<div class="form-group">
						<label for="pgid" class="col-sm-3 control-label">PayGate ID</label>
						<div class="col-sm-4">
							<input class="form-control" type="text" name="pgid" id="pgid" value="<?php echo(isset($pgid) ? $pgid : PayHostSOAP::$DEFAULT_PGID); ?>" />
						</div>
					</div>
					<div class="form-group">
						<label for="reference" class="col-sm-3 control-label">Reference</label>
						<div class="col-sm-6">
							<input class="form-control" type="text" name="reference" id="reference" value="<?php echo(isset($reference) ? $reference : generateReference()); ?>"/>
						</div>
					</div>
					<div class="form-group">
						<label for="amount" class="col-sm-3 control-label">Amount</label>
						<div class="col-sm-2">
							<input class="form-control" type="text" name="amount" id="amount" value="<?php echo(isset($amount) ? $amount : PayHostSOAP::$DEFAULT_AMOUNT); ?>"/>
						</div>
					</div>
					<div class="form-group">
						<label for="currency" class="col-sm-3 control-label">Currency</label>
						<div class="col-sm-2">
							<input class="form-control" type="text" name="currency" id="currency" value="<?php echo(isset($currency) ? $currency : PayHostSOAP::$DEFAULT_CURRENCY); ?>"/>
						</div>
					</div>
					<div class="form-group">
						<label for="transDate" class="col-sm-3 control-label">Transaction Date</label>
						<div class="col-sm-5">
							<input class="form-control" type="text" name="transDate" id="transDate" value="<?php echo(isset($transDate) ? $transDate : getDateTime('Y-m-d\TH:i:s')); ?>"/>
						</div>
					</div>
					<div class="form-group">
						<label for="locale" class="col-sm-3 control-label">Locale</label>
						<div class="col-sm-3">
							<input class="form-control" type="text" name="locale" id="locale" value="<?php echo(isset($locale) ? $locale : PayHostSOAP::$DEFAULT_LOCALE); ?>"/>
						</div>
					</div>
					<div class="form-group">
						<label for="encryptionKey" class="col-sm-3 control-label">Encryption Key</label>
						<div class="col-sm-5">
							<input class="form-control" type="text" name="encryptionKey" id="encryptionKey" value="<?php echo(isset($encryptionKey) ? $encryptionKey : PayHostSOAP::$DEFAULT_ENCRYPTION_KEY); ?>" />
						</div>
					</div>
					
					<div id="paymethodAndUserDiv" class="collapse well well-sm">
					
						
						
						<div class="form-group">
							<label for="email" class="col-sm-3 control-label">Email</label>
							<div class="col-sm-6">
								<input class="form-control" type="text" name="email" id="email" value="<?php echo(isset($email) ? $email : PayHostSOAP::$DEFAULT_EMAIL); ?>" placeholder="optional" />
							</div>
						</div>
				
					</div>
				
				
				
					
					<div class="form-group">
						<div class="col-sm-offset-4 col-sm-4">
							<button class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#addressDiv" aria-expanded="false" aria-controls="addressDiv">
								Address Fields
							</button>
						</div>
					</div>
					<div id="addressDiv" class="collapse well well-sm ">
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-9">
								<label class="checkbox-inline">
									<input name="incCustomer" id="incCustomer" type="checkbox" value="incCustomer" <?php echo (isset($incCustomer) && $incCustomer == 'incCustomer'?'checked="checked"':'' ); ?> /> Customer
								</label>
								<label class="checkbox-inline">
									<input name="incBilling" id="incBilling" type="checkbox" value="incBilling" <?php echo (isset($incBilling) && $incBilling == 'incBilling'?'checked="checked"':'' ); ?> /> Billing
								</label>
								<label class="checkbox-inline">
									<input name="incShipping" id="incShipping" type="checkbox" value="incShipping" <?php echo (isset($incShipping) && $incShipping == 'incShipping'?'checked="checked"':'' ); ?> /> Shipping
								</label>
							</div>
						</div>
						
						<div class="form-group">
							<label for="country" class="col-sm-3 control-label">Country</label>
							<div class="col-sm-6">
								<select name="country" id="country" class="form-control">
									<?php echo generateCountrySelectOptions(isset($country) ? $country : PayHostSOAP::$DEFAULT_COUNTRY); ?>
								</select>
							</div>
						</div>
					</div>
					
					<div id="redirectFieldsDiv" class="collapse well well-sm">
						<div class="form-group">
							<label for="retUrl" class="col-sm-3 control-label">Return URL</label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="retUrl" id="retUrl" value="<?php echo(isset($retUrl) ? $retUrl : $fullPath['protocol'] . $fullPath['host'] . '/' . $root . '/PayHost/result.php'); ?>" />
							</div>
						</div>
						<div class="form-group">
							<label for="notifyURL" class="col-sm-3 control-label">Notify URL</label>
							<div class="col-sm-9">
								<input class="form-control" type="text" name="notifyURL" id="notifyURL" value="<?php echo(isset($notifyURL) ? $notifyURL :$fullPath['protocol'] . $fullPath['host'] . '/' . $root . '/PayHost/notify.php'); ?>" />
							</div>
						</div>
					
					</div>
				
			
					<div class="form-group">
						<div class=" col-sm-offset-4 col-sm-4">
							
							<input class="btn btn-success btn-block" id="doAuthBtn" type="submit" name="btnSubmit" value="Do Auth" />
						</div>
					</div>
					<br>
				</form>
			<?php
				if (isset($_POST['btnSubmit'])) { ?>
					<div class="row" style="margin-bottom: 15px;">
						<div class="col-sm-offset-4 col-sm-4">
							<button id="showRequestBtn" class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#requestDiv" aria-expanded="false" aria-controls="requestDiv">
								Request
							</button>
						</div>
					</div>
					<div id="requestDiv" class="row collapse well well-sm">
				<?php
					//Show raw XML request DATA (only shows if 'trace' => 1)
					echo <<<HTML
						<textarea rows="20" cols="100" id="request" class="form-control">{$soapClient->__getLastRequest()}</textarea>
HTML;
				?>
					</div>
					<div class="row" style="margin-bottom: 15px;">
						<div class="col-sm-offset-4 col-sm-4">
							<button id="showResponseBtn" class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#responseDiv" aria-expanded="false" aria-controls="responseDiv">
								Response
							</button>
						</div>
					</div>
					<div id="responseDiv" class="row collapse well well-sm" >
				<?php  echo <<<HTML
				<textarea rows="20" cols="100" id="response" class="form-control">{$soapClient->__getLastResponse()}</textarea>
HTML;
				?>
					</div>
				<?php
					if (!$err){
						/*
						 * SOAP request has gone through without errors
						 */
						if (array_key_exists('Redirect', $result->WebPaymentResponse)){
							/*
							 * A redirect response was received from PayGate
							 */
							?>
					<div class="row" style="margin-bottom: 15px;">
						<div class="col-sm-offset-4 col-sm-4">
							<button id="showRedirectBtn" class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#redirectDiv" aria-expanded="false" aria-controls="redirectDiv">
								Redirect
							</button>
						</div>
					</div>
					<div id="redirectDiv" class="row collapse well well-sm" >
						<?php
							echo <<<HTML
						<textarea rows="20" cols="100" id="redirect" class="form-control">
<!-- form action passed back from WS -->
<form action="{$result->WebPaymentResponse->Redirect->RedirectUrl}" method="post">

HTML;
							foreach($result->WebPaymentResponse->Redirect->UrlParams as $url){
								/*
								 * Generate hidden inputs from the WebPaymentResponse
								 * (TextArea for display example purposes only)
								 */
								echo <<<HTML
	<input type="hidden" name="{$url->key}" value="{$url->value}" />

HTML;
							}
							echo <<<HTML
	<input type="submit" name="submitBtn" value="submit" />
</form>
                        </textarea>
HTML;
						?>
					</div>
					<form role="form" class="form-horizontal text-left" action="<?php echo $result->WebPaymentResponse->Redirect->RedirectUrl; ?>" method="post" style="margin-top: 15px;">
						<?php foreach ( $result->WebPaymentResponse->Redirect->UrlParams as $url) {
							/*
							 * Generate hidden inputs from the WebPaymentResponse
							 * (Actual form to redirect with)
							 */
							?>
							<input type="hidden" name="<?php echo $url->key;?>" value="<?php echo $url->value;?>" />
						<?php } ?>
						<br>
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-4">
								<img src="/<?php echo $root; ?>/lib/images/loader.gif" alt="Processing" class="initialHide" id="submitLoader">
								<input class="btn btn-success btn-block" type="submit" name="submitBtn" id="doSubmitBtn" value="submit" />
							</div>
						</div>
						<br>
					</form>
				<?php
						}
					}
				}  ?>
			</div>
		</div>
		<script type="text/javascript" src="/<?php echo $root; ?>/lib/js/jquery-1.10.2.min.js"></script>
		<script type="text/javascript" src="/<?php echo $root; ?>/lib/js/bootstrap.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('#doAuthBtn').on('click', function(){
					$(this).hide();
					$('#authLoader').show();
				});

				$('#doSubmitBtn').on('click', function(){
					$(this).hide();
					$('#submitLoader').show();
				});

				$('#addUserFieldBtn').on('click', function(){

					var lastUserFieldDiv = $('#fieldHolder').prev('.userDefined');

					var key   = lastUserFieldDiv.find('.userKey');

					var i = parseInt(key.attr('id').replace('userKey', ''));
					i++;

					var newUserFieldsDiv = '<div class="form-group userDefined">' +
						'    <label for="reference" class="col-sm-3 control-label">User Defined</label>' +
						'    <div class="col-sm-4">' +
						'        <input class="form-control userKey" type="text" name="userKey' + i + '" id="userKey' + i + '" value="" placeholder="Key" />' +
						'    </div>' +
						'    <div class="col-sm-4">' +
						'        <input class="form-control userField" type="text" name="userField' + i + '" id="userField' + i + '" value="" placeholder="Value" />' +
						'    </div>' +
						'</div>';

					$('#fieldHolder').before(newUserFieldsDiv);
				});
			});
		</script>
	</body>
</html>